# Require any additional compass plugins here.
# Set this to the root of your project when deployed:
http_path = "/"
css_dir = "/"
sass_dir = ""
images_dir = "images"
javascripts_dir = ""
fonts_dir = ""
relative_assets = true
 
line_comments = false
output_style = :compressed
# output_style = :compact :compressed :nested :expanded
# To enable relative paths to assets via compass helper functions. Uncomment:
# relative_assets = true
