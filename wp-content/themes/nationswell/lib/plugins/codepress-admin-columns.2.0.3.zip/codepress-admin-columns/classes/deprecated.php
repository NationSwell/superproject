<?php
/**
 * Deprecated Function, Hooks & Filters
 *
 */

/**
 * Deprecated Hooks
 *
 * @since 2.0
 */
// cpac-get-default-columns-comments	"cpac_before_default_columns_{$this->key}"
// cpac-get-default-columns-links		"cpac_before_default_columns_{$this->key}"
// cpac-get-default-columns-media		"cpac_before_default_columns_{$this->key}"
// cpac-get-default-columns-media		"cpac_before_default_columns_{$this->key}"
// cpac-get-default-columns-posts		"cpac_before_default_columns_posts"
// cpac-get-default-columns-posts		"cpac_before_default_columns_{$this->key}"
// cpac-get-default-columns-users		"cpac_before_default_columns_{$this->key}"
//
// cpac-manage-comments-column			WPcore: manage_comments_custom_column
// cpac-manage-link-column				WPcore: manage_link_custom_column
// cpac-manage-media-column				WPcore: manage_media_custom_column
// cpac-manage-posts-column				WPcore: manage_posts_custom_column, manage_pages_custom_column

/**
 * Deprecated Filters
 *
 * @since 2.0
 */
// cpac-default-comments-columns	cpac_default_{$this->key}_columns
// cpac-custom-comments-columns		cpac_custom_{$this->key}_columns
// cpac-get-meta-keys-comments		cpac_get_meta_keys_{$this->key}
//
// cpac-default-links-columns		cpac_default_{$this->key}_columns
// cpac-custom-links-columns		cpac_custom_{$this->key}_columns
//
// cpac-default-media-columns		cpac_default_{$this->key}_columns
// cpac-custom-media-columns		cpac_custom_{$this->key}_columns
// cpac-get-meta-keys-media			cpac_get_meta_keys_{$this->key}
//
// cpac-custom-posts-columns		cpac_custom_posts_columns
// cpac-custom-posts-columns		cpac_custom_{$this->key}_columns
// cpac-get-meta-keys-posts			cpac_get_meta_keys_{$this->key}

// cpac-default-users-columns		cpac_default_{$this->key}_columns
// cpac-custom-users-columns		cpac_custom_{$this->key}_columns
// cpac-get-meta-keys-users			cpac_get_meta_keys_{$this->key}
//
// cpac-field-types					cpac_field_types
// cpac-authorname-types			cpac_authorname_types
//
// cpac-get-orderby-type			cpac_get_orderby_type
// cpac-remove-filtering-columns	cpac_remove_filtering_columns
//
// cpac-get-post-types				cpac_get_post_types
//
// cpac-comments-column-result		cpac_{$this->key}_column_value
// cpac-link-column-result			cpac_{$this->key}_column_value
// cpac-media-column-result			cpac_{$this->key}_column_value
// cpac-posts-column-result			cpac_{$this->key}_column_value
// cpac-users-column-result			cpac_{$this->key}_column_value

